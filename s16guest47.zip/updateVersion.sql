CREATE PROCEDURE [dbo].[updateVersion]
(
@devReleaseId int
)
AS
BEGIN

--UPDATE table_name
--SET column1=value1,column2=value2,...
--WHERE some_column=some_value;

DECLARE @versionNumber AS int

UPDATE [dbo].[DevelopmentRelease]
SET versionNum = @versionNumber
where devReleaseId = @devReleaseId

END