CREATE PROCEDURE [dbo].[updateVersion]
(
@sourceId int
)
AS
BEGIN

SELECT count(featureId) 
FROM [dbo].[Source]
WHERE sourceId = @sourceId

END