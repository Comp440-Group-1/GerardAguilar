ALTER PROCEDURE [dbo].[initializeData]
AS
BEGIN

--GAA 6MAY2016: Having a lot of issues with Foreign Keys.

--Grabs the products from the sample and assigns our companyId = 3 to it
INSERT INTO dbo.Product (companyId, productName, productDescription )
SELECT DISTINCT 3, Product, Description 
FROM dbo.DataProductVersionRelease

--Grabs the different phone types from the sample data
INSERT INTO dbo.PhoneType (phoneType)
SELECT DISTINCT type
FROM dbo.ClientsDownloadRequest

--Grabs different companies
INSERT INTO dbo.CustomerCompany (custCompanyName, streetId, phoneId, zipId)
SELECT DISTINCT Company, 1, 1, 1
FROM dbo.ClientsDownloadRequest

--if not exists (select * from DataProductVersion d where d.phone = @phone and d.type = @type)
--    INSERT INTO Phone ([phoneType],[phoneNum]) values(@phone, @type)

--Insert[dbo].[Zip]([zipNum]) VALUES (91387)
--Insert[dbo].[Phone]([phoneTypeId], [phoneNum])
--VALUES (3, 7);

--DELETE FROM dbo.Phone
--WHERE phoneId = 3;

--Insert[dbo].[Customer]
--(
----custId,
--[subscriptionId],
--[streetId],
--[zipId],
--[phoneId],
--[customerFirstName],
--[customerLastName],
--[customerCompany]
--)
--VALUES()

SELECT * 
FROM dbo.Product;

SELECT *
FROM dbo.PhoneType

SELECT *
FROM dbo.CustomerCompany

END